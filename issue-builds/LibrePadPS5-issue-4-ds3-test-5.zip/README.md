# LibrePadPS5 DS3 USB test 5

Version: 1.1.4-ds3-test.5. This is the original published test 5 ELF, repackaged for issue #4 without rebuilding it.

The matching metadata uses local web upload and does not reference the retired release download.

1. Stop the running payload.
2. Extract this ZIP and load LibrePadPS5.elf. For Payload Manager, upload the ELF and JSON together.
3. Confirm 1.1.4-ds3-test.5 in the dashboard at http://YOUR_PS5_IP:8096/.
4. Connect one DS3, press physical PS, reconnect/assign its separate console user if necessary, then move sticks and press buttons for 30 seconds.
5. Download a fresh report from Advanced > Logs & support and attach it to https://github.com/arwebSE/LibrePadPS5/issues/4.

Test 5 adds the F4 USB reporting-enable request with payload 42 0c 00 00 and counters for physical USB reports, timeouts and pending reads. The original build and mocked sanitizer tests passed; sustained input on the reporter's console remains unverified.

Normal download: https://github.com/arwebSE/LibrePadPS5/releases/latest/download/LibrePadPS5.elf

ELF SHA-256: 79af67354e42c3cc1c98c955c7638f32021c99b9130b30a564ae0d790eee0c35
